module border_generator #(
    parameter SCREEN_WIDTH = 640,
    parameter SCREEN_HEIGHT = 480,
    parameter BORDER_SIZE = 8
)(
    input [9:0] hcount, vcount,
    output red_border
);
	assign red_border = (hcount < BORDER_SIZE || hcount >= (SCREEN_WIDTH - BORDER_SIZE) ||
                         vcount < BORDER_SIZE || vcount >= (SCREEN_HEIGHT - BORDER_SIZE));
endmodule
