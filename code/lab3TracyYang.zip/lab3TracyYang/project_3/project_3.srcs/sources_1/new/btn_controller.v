`timescale 1ns / 1ps

module btn_controller(
    input clk, btnL, btnR, btnU, btnD, btnC,
    output btnL_db, btnR_db, btnU_db, btnD_db, btnC_db
    );
    
    wire debounced_btnL, debounced_btnR, debounced_btnU, debounced_btnD, debounced_btnC;
    reg btnL_reg, btnR_reg, btnU_reg, btnD_reg, btnC_reg;
	
	debounce dbL (.clk(clk), .pb_1(btnL), .pb_out(debounced_btnL));
	debounce dbR (.clk(clk), .pb_1(btnR), .pb_out(debounced_btnR));
    debounce dbU (.clk(clk), .pb_1(btnU), .pb_out(debounced_btnU));
    debounce dbD (.clk(clk), .pb_1(btnD), .pb_out(debounced_btnD));
    debounce dbC (.clk(clk), .pb_1(btnC), .pb_out(debounced_btnC));
    
    always @(posedge clk) begin
        btnL_reg <= debounced_btnL;
        btnR_reg <= debounced_btnR;
        btnU_reg <= debounced_btnU;
        btnD_reg <= debounced_btnD;
        btnC_reg <= debounced_btnC;
    end
    
    assign btnL_db = ~btnL_reg & debounced_btnL;
    assign btnR_db = ~btnR_reg & debounced_btnR;
    assign btnU_db = ~btnU_reg & debounced_btnU;
    assign btnD_db = ~btnD_reg & debounced_btnD;
    assign btnC_db = ~btnC_reg & debounced_btnC;
    
endmodule
