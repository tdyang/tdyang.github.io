module pointer_controller #(
    parameter SCREEN_WIDTH = 640,
    parameter SCREEN_HEIGHT = 480,
    parameter BORDER_SIZE = 8,
    parameter POINTER_SIZE = 8
)( 
    input clk, reset, btnL, btnR, btnU, btnD,
    output reg [9:0] pX, pY
);
    localparam INIT_X = (SCREEN_WIDTH/2) - (POINTER_SIZE/2);
	localparam INIT_Y = (SCREEN_HEIGHT/2) - (POINTER_SIZE/2);
	
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            pX <= INIT_X;
            pY <= INIT_Y;
        end else begin
            if (btnL && pX > BORDER_SIZE) pX <= pX - POINTER_SIZE;
            if (btnR && pX < (SCREEN_WIDTH - BORDER_SIZE - POINTER_SIZE)) pX <= pX + POINTER_SIZE;
            if (btnU && pY > BORDER_SIZE) pY <= pY - POINTER_SIZE;
            if (btnD && pY < (SCREEN_HEIGHT - BORDER_SIZE - POINTER_SIZE)) pY <= pY + POINTER_SIZE;
        end
    end
endmodule
