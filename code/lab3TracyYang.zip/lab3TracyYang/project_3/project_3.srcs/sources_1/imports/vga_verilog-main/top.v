`timescale 1ns / 1ps

module vga_test(
	input clk, btnL, btnR, btnU, btnD, btnC,
	output Hsync, Vsync,
	output [3:0] vgaRed, vgaGreen, vgaBlue
);
	
	// ~~~ variable declaration ~~~ //
	wire clk_25mHz;
	wire btnL_db, btnR_db, btnU_db, btnD_db, btnC_db;
	reg [2:0] rgb;
	wire [9:0] hcount, vcount;
	wire blank;
	wire pointer_on, red_border;
	wire [9:0] pX, pY;
	
	// ~~~ param declaration ~~~ //
	localparam SCREEN_WIDTH = 640;
	localparam SCREEN_HEIGHT = 480;
	localparam BORDER_SIZE = 8;
	localparam POINTER_SIZE = 8;
	
    // ~~~ module instantiations ~~~ //
    clk_wiz_0 clkgen (
        .clk_in1(clk),
        .clk_out1(clk_25mHz)
    );
    
    // ~~~ debounced buttons ~~~ //
	btn_controller btn_db (
	   .clk(clk_25mHz),
	   .btnL(btnL), .btnR(btnR), .btnU(btnU), .btnD(btnD), .btnC(btnC),
	   .btnL_db(btnL_db), .btnR_db(btnR_db), .btnU_db(btnU_db), .btnD_db(btnD_db), .btnC_db(btnC_db)
    );
    
    vga_controller vga_inst(
        .clk(clk_25mHz), 
        .hsync(Hsync), 
        .vsync(Vsync),
        .hcount(hcount), 
        .vcount(vcount),
        .blank(blank)
    );
    
    pointer_controller #(
        .SCREEN_WIDTH(SCREEN_WIDTH),
        .SCREEN_HEIGHT(SCREEN_HEIGHT),
        .BORDER_SIZE(BORDER_SIZE),
        .POINTER_SIZE(POINTER_SIZE))
    pointer_inst(
        .clk(clk_25mHz), 
        .reset(btnC_db),
        .btnL(btnL_db),
        .btnR(btnR_db),
        .btnU(btnU_db),
        .btnD(btnD_db),
        .pX(pX),
        .pY(pY)
    );
    
    border_generator #(
        .SCREEN_WIDTH(SCREEN_WIDTH),
        .SCREEN_HEIGHT(SCREEN_HEIGHT),
        .BORDER_SIZE(BORDER_SIZE))
    border_inst(
        .hcount(hcount),
        .vcount(vcount),
        .red_border(red_border)
    );
    
    assign pointer_on = (hcount >= pX && hcount < (pX + 8) &&
                         vcount >= pY && vcount < (pY + 8));
        
    // ~~~ rgb buffer ~~~ //
    always @(posedge clk_25mHz) begin
        if (blank) rgb <= 3'b000;
        else if (red_border) rgb <= 3'b100;
        else if (pointer_on) rgb <= 3'b111;
        else rgb <= 3'b000;
    end
    
    assign vgaRed = {rgb[2], rgb[2], rgb[2], rgb[2]};
    assign vgaGreen = {rgb[1], rgb[1], rgb[1], rgb[1]};
    assign vgaBlue = {rgb[0], rgb[0], rgb[0], rgb[0]};
    
endmodule