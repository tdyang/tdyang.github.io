module vga_controller (
    input clk,
    output reg hsync, vsync,
    output reg [9:0] hcount, vcount,
    output blank
);

    // ~~~ param declaration ~~~ //
    localparam H_VISIBLE_AREA = 640;
    localparam H_FRONT_PORCH  = 16;
    localparam H_SYNC_PULSE   = 96;
    localparam H_BACK_PORCH   = 48;
    localparam H_TOTAL        = 800;

    localparam V_VISIBLE_AREA = 480;
    localparam V_FRONT_PORCH  = 10;
    localparam V_SYNC_PULSE   = 2;
    localparam V_BACK_PORCH   = 33;
    localparam V_TOTAL        = 525;

    always @(posedge clk) begin
        if (hcount == H_TOTAL - 1) begin
            hcount <= 0;
            if (vcount == V_TOTAL - 1) begin
                vcount <= 0;
            end else begin
                vcount <= vcount + 1;
            end
        end else begin
            hcount <= hcount + 1;
        end
        
        hsync <= (hcount >= H_VISIBLE_AREA + H_FRONT_PORCH) && 
                  (hcount < H_VISIBLE_AREA + H_FRONT_PORCH + H_SYNC_PULSE);

        vsync <= (vcount >= V_VISIBLE_AREA + V_FRONT_PORCH) && 
                  (vcount < V_VISIBLE_AREA + V_FRONT_PORCH + V_SYNC_PULSE);
    end
    
    assign blank = (hcount >= H_VISIBLE_AREA) || (vcount >= V_VISIBLE_AREA);
endmodule
