/*
 * ECE 3849 Lab2 starter project
 *
 * Gene Bogdanov    9/13/2017
 */
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/cfg/global.h>
#include "kiss_fft.h"
#include "_kiss_fft_guts.h"

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

#include <stdint.h>
#include <stdbool.h>
#include "driverlib/interrupt.h"
#include "driverlib/fpu.h"
#include "driverlib/sysctl.h"
#include "Crystalfontz128x128_ST7735.h"
#include <stdio.h>
#include "buttons.h"
#include "adc_sampling.h"
#include <math.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "driverlib/timer.h"

#define PWM_FREQUENCY 20000

uint32_t gSystemClock; // [Hz] system clock frequency
volatile uint32_t gTime = 8345; // time in hundredths of a second
volatile uint32_t triggerVoltage = 2048;
volatile uint16_t triggerDirection = 0;
volatile uint16_t scaleState = 0;
volatile bool gSnapshot = false;
volatile bool gLive = true;
volatile uint32_t CountUnloaded;
volatile uint16_t mode; // Mode 1: Oscilloscope, Mode 0: Spectrum
volatile uint16_t gSpectrum[1024];
volatile uint16_t spectrumDraw[1024];
volatile uint16_t ADCSpectrum[1024];
#define NFFT 1024
#define KISS_FFT_CFG_SIZE (sizeof(struct kiss_fft_state)+sizeof(kiss_fft_cpx)*(NFFT-1))

// outside variables
extern volatile uint16_t ADCDraw[128];

uint32_t gSystemClock = 120000000; // [Hz] system clock frequency

int Snapshot(int triggerDirection, uint16_t triggerVoltage);
void drawGrid(tContext sContext);
volatile int processingBuffer[128];
float fScale;

void SignalInit(void) {
    // M0PWM2, at GPIO PF2= BoosterPack 1 header C1 pin 2
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_2);
    GPIOPinConfigure(GPIO_PF2_M0PWM2);
    GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_2, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD);

    // PWM0 peripheral, gen 1, outputs 2 & 3
    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);

    // system clock w/o division
    PWMClockSet(PWM0_BASE, PWM_SYSCLK_DIV_1);
    PWMGenConfigure(PWM0_BASE, PWM_GEN_1, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);
    PWMGenPeriodSet(PWM0_BASE, PWM_GEN_1, roundf((float)gSystemClock/PWM_FREQUENCY));
    PWMPulseWidthSet(PWM0_BASE, PWM_OUT_2, roundf((float)gSystemClock/PWM_FREQUENCY*0.4f));
    PWMOutputState(PWM0_BASE, PWM_OUT_2_BIT, true);
    PWMGenEnable(PWM0_BASE, PWM_GEN_1);
}


uint32_t CPULoadCount(void) {
    uint32_t CPUUtil = 0;
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER3_BASE, TIMER_A);
    while (!(TimerIntStatus(TIMER3_BASE, false) & TIMER_TIMA_TIMEOUT))
        CPUUtil++;
    return CPUUtil;
}

/*
 *  ======== main ========
 */
#define PI 3.14159265358979f
//#define NFFT 1024 // FFT length
//#define KISS_FFT_CFG_SIZE (sizeof(struct kiss_fft_state)+sizeof(kiss_fft_cpx)*(NFFT-1))

int main(void) {
    IntMasterDisable();

    SignalInit();
    ADCSamplingInit();
    ButtonInit();
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);
        TimerDisable(TIMER3_BASE, TIMER_BOTH);
        TimerConfigure(TIMER3_BASE, TIMER_CFG_ONE_SHOT);
        TimerLoadSet(TIMER3_BASE, TIMER_A, gSystemClock / 100); // change number to change refresh time
        CountUnloaded = CPULoadCount();
    CPULoadCount();


    /* Start BIOS */
    BIOS_start();

    return (0);
}

void buttonScanClock(UArg arg0, UArg arg1) {
    Semaphore_post(buttonSem);
}

void buttonTaskFunc(UArg arg0, UArg arg1) {
    IntMasterEnable();

    while (true) {
        Semaphore_pend(buttonSem, BIOS_WAIT_FOREVER);

        // read hardware button state
        uint32_t gpio_buttons =
                ~GPIOPinRead(GPIO_PORTJ_BASE, 0xff) & (GPIO_PIN_1 | GPIO_PIN_0) // EK-TM4C1294XL buttons in positions 0 and 1
                | ((~GPIOPinRead(GPIO_PORTH_BASE, 0xff) & GPIO_PIN_1) << 1) // BoosterPack button S1
                | ((~GPIOPinRead(GPIO_PORTK_BASE, 0xff) & GPIO_PIN_6) >> 3) // BoosterPack button S2
                | (~GPIOPinRead(GPIO_PORTD_BASE, 0xff) & GPIO_PIN_4); // BoosterPack button joystick SEL

        uint32_t old_buttons = gButtons;    // save previous button state
        ButtonDebounce(gpio_buttons);       // Run the button debouncer. The result is in gButtons.
        ButtonReadJoystick();               // Convert joystick state to button presses. The result is in gButtons.
        uint32_t presses = ~old_buttons & gButtons;   // detect button presses (transitions from not pressed to pressed)
        presses |= ButtonAutoRepeat();      // autorepeat presses if a button is held long enough

        static bool tic = false;
        static bool running = true;

        int i;
        for(i = 0; i <= 8; i++) {
            ButtonID id = (ButtonID)(1 << i);
            if (presses & id) {
                Mailbox_post(buttonMailbox, &id, BIOS_NO_WAIT);
            }
        }

        if (running) {
            if (tic) gTime++; // increment time every other ISR call
            tic = !tic;
        }
    }
}

void userInputTaskFunc(UArg arg0, UArg arg1) {
    IntMasterEnable();
    ButtonID receivedButton;

    while (true) {
        if (Mailbox_pend(buttonMailbox, &receivedButton, BIOS_WAIT_FOREVER)) {
            switch (receivedButton) {
            case BUTTON_EK1:
                mode ^= 1;
                break;
            case BUTTON_EK2:
                gLive = !gLive;
                if (!gLive)
                    gSnapshot = true;
                break;
            case BUTTON_S1:
                triggerDirection = !triggerDirection;

                if (!gLive) {
//                    Task_sleep(3 * (1000 / Clock_tickPeriod));
                    gSnapshot = true;
                    Semaphore_post(waveformSem);
                } else
                    gSnapshot = false;

                Semaphore_post(displaySem);
                break;
            case BUTTON_S2:
                scaleState = (scaleState + 1) % 5;
                gSnapshot = true;
                break;
            case BUTTON_JS_SEL:
                //mode ^= 1;
                break;
            default:
                break;
            }
        }
    }
}

void waveformTaskFunc(UArg arg0, UArg arg1) {
    IntMasterEnable();
    Semaphore_post(waveformSem);

    while (true) {
        Semaphore_pend(waveformSem, BIOS_WAIT_FOREVER);

        // perform trigger search
        if (gLive) {
            Snapshot(triggerDirection, triggerVoltage);
        } else if (gSnapshot){
            Snapshot(triggerDirection, triggerVoltage);
            gSnapshot = false;
        }

        // signal processing task
        Semaphore_post(processingSem);
    }
}

void processingTaskFunc(UArg arg0, UArg arg1) {
    IntMasterEnable();

    static char kiss_fft_cfg_buffer[KISS_FFT_CFG_SIZE]; // Kiss FFT config memory
    size_t buffer_size = KISS_FFT_CFG_SIZE;
    kiss_fft_cfg cfg; // Kiss FFT config
    static kiss_fft_cpx in[NFFT], out[NFFT]; // Complex waveform and spectrum buffers
    static float w[NFFT]; // Window function
    int i;


    // Initialize Blackman window
    for (i = 0; i < NFFT; i++) {
        w[i] = 0.42f - 0.5f * cosf(2 * PI * i / (NFFT - 1))
                     + 0.08f * cosf(4 * PI * i / (NFFT - 1));
    }

    cfg = kiss_fft_alloc(NFFT, 0, kiss_fft_cfg_buffer, &buffer_size); // Init Kiss FFT

    while (true) {
        Semaphore_pend(processingSem, BIOS_WAIT_FOREVER);

        if (mode) {
            // Oscilloscope mode
            fScale = changeScale(scaleState);
            for (i = 0; i < 127; i++) {
                int sample = ADCDraw[i];
                int nextSample = ADCDraw[i + 1];
                int centerY = LCD_VERTICAL_MAX / 2;
                float amplitude = (LCD_VERTICAL_MAX / 4) / fScale;
                if (amplitude > (LCD_VERTICAL_MAX/2) - 1)
                    amplitude = (LCD_VERTICAL_MAX/2) - 1;

                int currentY = roundf(centerY - ((sample - 2048) * amplitude) / 2048);
                int nextY = roundf(centerY - ((nextSample - 2048) * amplitude) / 2048);
                processingBuffer[i] = currentY;
                processingBuffer[i + 1] = nextY;
            }
        } else {
            // Spectrum Analyzer mode using real ADC samples

            for (i = 0; i < NFFT; i++) {
                in[i].r = ADCSpectrum[i]; // ((float)(ADCSpectrum[i]) - 2048.0f) * w[i];  // windowed, centered
                in[i].i = 0.0f;
            }

            kiss_fft(cfg, in, out);
            //out[i].r = i;
            //out[i].i = 0;


            for (i = 0; i < 128; i++) { // First 128 bins = 0�~6kHz at 48kHz
                float real = out[i].r;
                float imag = out[i].i;
                float mag_sq = real * real + imag * imag;


                //float mag_sq = 1;
                float dB = 10.0f * log10f(mag_sq);
                int yVal = 120 - (int)(dB + 1.0f); // Scale to screen

                //if (yVal < 0) yVal = 0;
                //if (yVal > 120) yVal = 120;

                spectrumDraw[i] = yVal;
            }
        }

        Semaphore_post(displaySem);
        Semaphore_post(waveformSem);
    }
}




void displayTaskFunc(UArg arg0, UArg arg1) {
    IntMasterEnable();
    Crystalfontz128x128_Init(); // Initialize the LCD display driver
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP); // Set screen orientation
    tContext sContext;
    GrContextInit(&sContext, &g_sCrystalfontz128x128); // Initialize the grlib graphics context
    GrContextFontSet(&sContext, &g_sFontFixed6x8); // Select font

    tRectangle rectFullScreen = {0, 0, GrContextDpyWidthGet(&sContext) - 1, GrContextDpyHeightGet(&sContext) - 1};
    char strScale[50];
    char strLoad[50];
    char strTrigger[50];

    // screen math
    int screenWidth = GrContextDpyWidthGet(&sContext);
    int screenHeight = GrContextDpyHeightGet(&sContext);
    int x;
    int y;

    while (true) {
        Semaphore_pend(displaySem, BIOS_WAIT_FOREVER);

        GrContextForegroundSet(&sContext, ClrBlack);
        GrRectFill(&sContext, &rectFullScreen); // Fill screen with black

        GrContextForegroundSet(&sContext, ClrBlue); // Set grid color

        for (x = screenWidth / 2; x < screenWidth; x += PIXELS_PER_DIV)
            GrLineDraw(&sContext, x, 0, x, screenHeight);

        for (x = screenWidth / 2; x > 0; x -= PIXELS_PER_DIV)
            GrLineDraw(&sContext, x, 0, x, screenHeight);

        for (y = screenHeight / 2; y < screenHeight; y += PIXELS_PER_DIV)
            GrLineDraw(&sContext, 0, y, screenWidth, y);

        for (y = screenHeight / 2; y > 0; y -= PIXELS_PER_DIV)
            GrLineDraw(&sContext, 0, y, screenWidth, y);

        // Text displays
        GrContextForegroundSet(&sContext, ClrWhite);

        // Scale display
        snprintf(strScale, sizeof(strScale), "Scale: %.1f", fScale);
        GrStringDraw(&sContext, strScale, -1, 0, 0, false);

        // CPU load display
        uint32_t CountLoaded = CPULoadCount();
        float CPULoad = 1.0f - (float) CountLoaded / CountUnloaded;
        snprintf(strLoad, sizeof(strLoad), "CPU Load: %.02f", (CPULoad * 100));
        GrStringDraw(&sContext, strLoad, -1, 0, 40, false);

        // Trigger direction display
        const char *cTrigger;
        if (triggerDirection)
            cTrigger = "rising";
        else
            cTrigger = "falling";
        snprintf(strTrigger, sizeof(strTrigger), "Trigger: %s", cTrigger);
        GrStringDraw(&sContext, strTrigger, -1, 0, 20, false);

        // Draw graph
        GrContextForegroundSet(&sContext, ClrYellow); // Set sample color

        int i;
        for (i = 0; i < 127; i++) {   // <--- drawing lines between pairs
            if (mode) {
                int sample = processingBuffer[i];
                int nextSample = processingBuffer[i + 1];
                GrLineDraw(&sContext, i, sample, i + 1, nextSample);
            } else {
                int sample = spectrumDraw[i];
                int nextSample = spectrumDraw[i + 1];
                GrLineDraw(&sContext, i, sample, i + 1, nextSample);
            }
        }

        GrFlush(&sContext); // Flush the frame buffer to the LCD
    }
}


/*
void displayTaskFunc(UArg arg0, UArg arg1) {
    IntMasterEnable();
    Crystalfontz128x128_Init(); // Initialize the LCD display driver
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP); // set screen orientation
    tContext sContext;
    GrContextInit(&sContext, &g_sCrystalfontz128x128); // Initialize the grlib graphics context
    GrContextFontSet(&sContext, &g_sFontFixed6x8); // select font

    tRectangle rectFullScreen = {0, 0, GrContextDpyWidthGet(&sContext)-1, GrContextDpyHeightGet(&sContext)-1};
    char strScale[50];
    char strLoad[50];
    char strTrigger[50];

    // screen math
    int screenWidth = GrContextDpyWidthGet(&sContext);
    int screenHeight = GrContextDpyHeightGet(&sContext);
    int x;
    int y;

    while (true) {
        Semaphore_pend(displaySem, BIOS_WAIT_FOREVER);
        GrContextForegroundSet(&sContext, ClrBlack);
        GrRectFill(&sContext, &rectFullScreen); // fill screen with black

        GrContextForegroundSet(&sContext, ClrBlue); // set grid color

        for (x = screenWidth / 2; x < screenWidth; x += PIXELS_PER_DIV)
            GrLineDraw(&sContext, x, 0, x, screenHeight);

        for (x = screenWidth / 2; x > 0; x -= PIXELS_PER_DIV)
            GrLineDraw(&sContext, x, 0, x, screenHeight);

        for (y = screenHeight / 2; y < screenHeight; y += PIXELS_PER_DIV)
            GrLineDraw(&sContext, 0, y, screenWidth, y);

        for (y = screenHeight / 2; y > 0; y -= PIXELS_PER_DIV)
            GrLineDraw(&sContext, 0, y, screenWidth, y);

        // text displays
        GrContextForegroundSet(&sContext, ClrWhite);
        // scale print
        GrStringDraw(&sContext, strScale, -1, 0,  0,  false);
        snprintf(strScale, sizeof(strScale), "Scale: %.1f", fScale);

        //cpu load print

        uint32_t CountLoaded = CPULoadCount();
        float CPULoad = 1.0f - (float) CountLoaded / CountUnloaded;
        GrStringDraw(&sContext, strLoad, -1, 0, 40, false);
        snprintf(strLoad, sizeof(strLoad), "CPU Load: %.02f", (CPULoad * 100));



        // trigger direction print
        const char *cTrigger;
        if (triggerDirection)
            cTrigger = "rising";
        else
            cTrigger = "falling";
        GrStringDraw(&sContext, strTrigger, -1, 0, 20, false);
        snprintf(strTrigger, sizeof(strTrigger), "Trigger: %s", cTrigger);

        // draw one frame to LCD
        GrContextForegroundSet(&sContext, ClrYellow); // set sample color
        int i;
        for (i = 0; i < 127; i++) {
            int sample = processingBuffer[i];
            int nextSample = processingBuffer[i + 1];

            GrLineDraw(&sContext, i, sample, i + 1, nextSample);
        }

        GrFlush(&sContext); // flush the frame buffer to the LCD
    }
}*/

