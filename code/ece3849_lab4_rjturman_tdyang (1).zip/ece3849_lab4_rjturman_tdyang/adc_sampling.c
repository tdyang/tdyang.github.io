/*
 * adc_sampling.c
 *
 */
#include <adc_sampling.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "driverlib/adc.h"
#include "sysctl_pll.h"
#include "inc/tm4c1294ncpdt.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "Crystalfontz128x128_ST7735.h"
#include "buttons.h"

// public global variables
volatile int32_t gADCBufferIndex = ADC_BUFFER_SIZE - 1; // latest sample index
volatile uint16_t gADCBuffer[ADC_BUFFER_SIZE];          // circular buffer
volatile uint32_t gADCErrors = 0;                       // number of missed ADC deadlines
volatile uint32_t ADCIndex;
volatile uint16_t ADCDraw[128];
volatile float flatlineValue = 0.0f;
extern volatile uint16_t ADCSpectrum[1024];
#define PI 3.14159265358979f
#define NFFT 1024

// imported global variables
extern uint32_t gADCSamplingRate;   // [Hz] actual ADC sampling rate
extern uint32_t gSystemClock;       // [Hz] system clock frequency
extern volatile uint32_t gTime;     // time in hundredths of a second
extern volatile uint32_t triggerVoltage;
extern volatile uint16_t mode;
extern volatile uint32_t presses;


void ADCSamplingInit(void)
{
    // initialize ADC0 peripheral
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);

    // initialize ADC1 peripheral at GPIO PE0
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_0); // GPIO setup for analog input AIN3
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC1);

    // initialize ADC clock configuration
    uint32_t pll_frequency = SysCtlFrequencyGet(CRYSTAL_FREQUENCY);
    uint32_t pll_divisor = (pll_frequency - 1) / (16 * ADC_SAMPLING_RATE) + 1; // round up
    ADCClockConfigSet(ADC0_BASE, ADC_CLOCK_SRC_PLL | ADC_CLOCK_RATE_FULL, pll_divisor);
    ADCClockConfigSet(ADC1_BASE, ADC_CLOCK_SRC_PLL | ADC_CLOCK_RATE_FULL, pll_divisor);
    gADCSamplingRate = pll_frequency / (16 * pll_divisor);

    // initialize ADC1 sampling sequence 0 w/ priority 0 step 0
    ADCSequenceDisable(ADC1_BASE, 0);
    ADCSequenceConfigure(ADC1_BASE, 0, ADC_TRIGGER_ALWAYS, 0);
    ADCSequenceStepConfigure(ADC1_BASE, 0, 0, ADC_CTL_IE | ADC_CTL_END | ADC_CTL_CH3);  // 0th step, sample channel 3 (AIN3), enable interrupt, +end of sequence
    ADCSequenceEnable(ADC1_BASE, 0);                // enable the sequence. it is now sampling
    ADCIntEnable(ADC1_BASE, 0);                     // enable sequence 0 interrupt in the ADC1 peripheral
    IntPrioritySet(INT_ADC0SS0, ADC_INT_PRIORITY);  // set ADC1 sequence 0 interrupt priority
    IntEnable(INT_ADC1SS0);                         // enable ADC1 sequence 0 interrupt in int. controller
}

void ADC_ISR(void) {
    // acquires sample & interrupts every 1us
//    ADCIntClearEx(ADC1_BASE, ADC1_ISC_R); // clear ADC1 sequence0 interrupt flag in the ADCISC register
    ADC1_ISC_R = 1;

    if (ADC1_OSTAT_R & ADC_OSTAT_OV0) { // check for ADC FIFO overflow
        gADCErrors++;                   // count errors
        ADC1_OSTAT_R = ADC_OSTAT_OV0;   // clear overflow condition
    }
    gADCBuffer[gADCBufferIndex = ADC_BUFFER_WRAP(gADCBufferIndex + 1)
                ] = ADC1_SSFIFO0_R; // read sample from the ADC1 sequence 0 FIFO
}



int Snapshot(int triggerDirection, uint16_t triggerVoltage) {
    uint16_t prevVoltage = 0;
    ADCIndex = ADC_BUFFER_WRAP(gADCBufferIndex - 64);
    prevVoltage = gADCBuffer[ADCIndex];

    bool edgeDetected = false;
    int searchCount = 0;

    while (searchCount < MAX_EDGE_SEARCH) {
        float currentVoltage = gADCBuffer[ADCIndex];
        if (triggerDirection == 0) {  // rising edge
            if (prevVoltage < triggerVoltage && currentVoltage >= triggerVoltage) {
                edgeDetected = true;
                break;
            }
        } else if (triggerDirection == 1) {  // falling edge
            if (prevVoltage > triggerVoltage && currentVoltage <= triggerVoltage) {
                edgeDetected = true;
                break;
            }
        }
        prevVoltage = currentVoltage;
        ADCIndex = ADC_BUFFER_WRAP(ADCIndex - 1);
        searchCount++;
    }

    int cnt;

    // Always collect 128 samples for oscilloscope
    if (!edgeDetected) {
        for (cnt = 0; cnt < 128; cnt++) {
            ADCDraw[cnt] = gADCBuffer[ADCIndex];
            ADCIndex = ADC_BUFFER_WRAP(ADCIndex + 1);
        }
    } else {
        ADCIndex = ADC_BUFFER_WRAP(ADCIndex - 63);
        for (cnt = 0; cnt < 128; cnt++) {
            ADCDraw[cnt] = gADCBuffer[ADCIndex];
            ADCIndex = ADC_BUFFER_WRAP(ADCIndex + 1);
        }
    }

    // If in spectrum mode, also fill the 1024-sample buffer
    if (mode == 0) {
        ADCIndex = ADC_BUFFER_WRAP(gADCBufferIndex - NFFT);  // Go back NFFT samples
        for (cnt = 0; cnt < NFFT; cnt++) {
            ADCSpectrum[cnt] = gADCBuffer[ADCIndex];
            ADCIndex = ADC_BUFFER_WRAP(ADCIndex + 1);
        }
    }

    return 0;
}


float changeScale(int state) {
    switch (state) {
        case 0: return .1; // 100mV
        case 1: return .2; // 200 mV
        case 2: return .5; // 500 mV
        case 3: return 1;  // 1V
        case 4: return 2;  // 2V
        default: return 1;
    }

}
