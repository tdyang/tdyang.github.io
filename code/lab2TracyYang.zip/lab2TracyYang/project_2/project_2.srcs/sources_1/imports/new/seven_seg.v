`timescale 1ns / 1ps

module seven_seg(
    input [15:0] sw,
    input clk, reset,
    output reg [3:0] an,
    output reg [6:0] seg
    );
    
    parameter C_MAX_COUNT = 8000000;
    reg [23:0] led_counter;
    
    function [6:0] hex_seg;
        input [3:0] data;
        case (data)            
            4'h0: hex_seg = 7'b1000000;    // digit 0
            4'h1: hex_seg = 7'b1111001;    // digit 1
            4'h2: hex_seg = 7'b0100100;    // digit 2
            4'h3: hex_seg = 7'b0110000;    // digit 3
            4'h4: hex_seg = 7'b0011001;    // digit 4
            4'h5: hex_seg = 7'b0010010;    // digit 5
            4'h6: hex_seg = 7'b0000010;    // digit 6
            4'h7: hex_seg = 7'b1111000;    // digit 7
            4'h8: hex_seg = 7'b0000000;    // digit 8
            4'h9: hex_seg = 7'b0010000;    // digit 9
            4'ha: hex_seg = 7'b0001000;    // digit A
            4'hb: hex_seg = 7'b0000011;    // digit B
            4'hc: hex_seg = 7'b1000110;    // digit C
            4'hd: hex_seg = 7'b0100001;    // digit D
            4'he: hex_seg = 7'b0000110;    // digit E
            4'hf: hex_seg = 7'b0001110;    // digit F
            default: hex_seg = 7'b1111111;
        endcase
    endfunction
    
    always @(posedge clk or posedge reset) begin
        if (reset)
            led_counter <= 0;
        else begin
            if (led_counter == C_MAX_COUNT)
                led_counter <= 24'd0;
            else
                led_counter <= led_counter + 1;
        end
     end
    
    always @(*) begin
        case(led_counter[19:18])
            2'b00 : begin
                an = 4'b1110;
                seg = hex_seg(sw[3:0]);
            end 
            2'b01 : begin
                an = 4'b1101;
                seg = hex_seg(sw[7:4]);
            end
            2'b10 : begin
                an = 4'b1011;
                seg = hex_seg(sw[11:8]);
            end
            2'b11 : begin
                an = 4'b0111;
                seg = hex_seg(sw[15:12]);
            end
        endcase
    end
endmodule
