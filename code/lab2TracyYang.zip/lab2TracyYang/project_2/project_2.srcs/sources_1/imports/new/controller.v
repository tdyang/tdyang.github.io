`timescale 1ns / 1ps

module controller(
    input           clk, btnL, btnR,  
    input [7:0]     sw,
    output [3:0]    an,
    output [6:0]    seg,
    output [15:0]   led
    );
    
    wire [15:0] segval;
    wire debounced_btnL, debounced_btnR, btnle, btnre;
    reg btnlr, btnrr;
    
    debounce dbL (
        .clk(clk),
        .pb_1(btnL),
        .pb_out(debounced_btnL)
    );
    
    debounce dbR (
        .clk(clk),
        .pb_1(btnR),
        .pb_out(debounced_btnR)
    );
    
    
    always @(posedge clk) begin
        btnlr <= debounced_btnL;
        btnrr <= debounced_btnR;
    end
    
    assign btnle = ~btnlr & debounced_btnL;
    assign btnre = ~btnrr & debounced_btnR;
    
    // -- submodule instances -- //  
    cal_function CF(
        .clk(clk),
        .reset(btnle),
        .btnR(btnre),
        .sw(sw),
        .segval(segval),
        .led(led)
    );            
    
    seven_seg disp(
        .clk(clk),
        .reset(btnle),
        .sw(segval),      
        .an(an), 
        .seg(seg)
    );   
endmodule
