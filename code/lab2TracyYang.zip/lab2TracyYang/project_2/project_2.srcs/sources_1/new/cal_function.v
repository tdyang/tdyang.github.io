`timescale 1ns / 1ps

module cal_function(
    input [7:0]         sw,
    input               clk, reset, btnR,
    output reg [15:0]   segval,
    output reg [15:0]   led
    );
    
    reg [7:0] first_operand, second_operand, result;
    reg [2:0] operation;
    reg [1:0] flags;
    
    // -- state machine vars -- //
    parameter s_idle = 2'b00;
    parameter s_first_input = 2'b01;
    parameter s_second_input = 2'b10;
    parameter s_calculation = 2'b11;
    reg [1:0] curr_state, next_state;
    
     // -- calculation operations -- //
    parameter s_xor = 3'b000;
    parameter s_and = 3'b001;
    parameter s_or = 3'b010;
    parameter s_add = 3'b011;
    parameter s_sub = 3'b100; 
    
    // ~~~ state & clock ~~~ //
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            curr_state <= s_idle;
        end else begin
            curr_state <= next_state;
        end
    end
    
    always @(*) begin
        case (curr_state)
            s_idle : begin
                led[15:12] = 4'b1000;
                led[3:0] = 4'b0000;
                if (sw) next_state = s_first_input;
                else if (reset) next_state = s_idle;
                else next_state = s_idle;
            end
            s_first_input : begin
                led[15:12] = 4'b0100;
                if (btnR) next_state = s_second_input;
                else if (reset) next_state = s_idle;
                else next_state = s_first_input;
            end
            s_second_input : begin
                led[15:12] = 4'b0010;
                if (btnR) next_state = s_calculation;
                else if (reset) next_state = s_idle;
                else next_state = s_second_input;
            end
            s_calculation : begin
                if (reset) next_state = s_idle;
                else next_state = s_calculation;
                led[15:12] = 4'b0001;
                case (operation)
                    s_xor : led [3:0] = 4'b1000;
                    s_and : led [3:0] = 4'b1001;
                    s_or  : led [3:0] = 4'b1010;
                    s_add : led [3:0] = 4'b1011;
                    s_sub : led [3:0] = 4'b1100;
                    default: led [3:0] = 0;
                endcase
            end
            default : next_state = s_idle;
        endcase 
    end
    
    // ~~~ result logic ~~~ //        
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            operation <= 0;
            first_operand <= 0;
            second_operand <= 0;
            flags <= 0;
            result <= 0;
        end else begin                
            if (curr_state == s_idle) begin
                operation <= 0;
                first_operand <= 0;
                second_operand <= 0;
                flags <= 0;
                result <= 0;
            end
            if (curr_state == s_first_input) begin
                first_operand <= sw;
                flags <= 2'b01;
            end
            if (curr_state == s_second_input) begin
                second_operand <= sw;
                flags <= 2'b10;
            end
            if (curr_state == s_calculation) begin
                operation <= sw[2:0];
                
                case (operation)
                    s_xor : result <= first_operand ^ second_operand;
                    s_and : result <= first_operand & second_operand;
                    s_or  : result <= first_operand | second_operand;
                    s_add : result <= first_operand + second_operand;
                    s_sub : result <= first_operand - second_operand;
                    default: result <= 0;
                endcase 
            
                flags <= 2'b11;
            end
        end         
    end
    
    // ~~~ segval logic ~~~ //
    always @(*) begin
        case (flags)
            2'b00 : segval = {sw, 8'd0};
            2'b01 : segval = {sw, 8'd0};
            2'b10 : segval = {first_operand, sw};
            2'b11 : segval = {result, 8'd0};
            default : segval = {sw, 8'd0};
        endcase
    end
endmodule
