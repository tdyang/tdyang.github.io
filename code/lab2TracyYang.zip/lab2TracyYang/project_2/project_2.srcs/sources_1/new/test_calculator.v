`timescale 1ns / 1ps

module test_calculator();
    reg clk, reset, btnR;
    reg [7:0] sw;
    wire [3:0] an;
    wire [6:0] seg;
    wire [15:0] led;
    
    controller dut (
        .clk(clk),
        .btnL(reset),
        .btnR(btnR),
        .sw(sw),
        .an(an),
        .seg(seg),
        .led(led)
    );
    
    always begin   
        # 10 clk = ~clk;
    end
    
    // ~~ TASKS ~~~ //
    task press_button;
        begin
            btnR = 1;
            #20;
            btnR = 0;
        end
    endtask
    
    task apply_operand (input [7:0] operand);
        begin
            sw = operand;
            press_button();
            #100;
        end
    endtask
    
    task perform_operation (input [2:0] op_code);
        begin
            sw = {5'b0, op_code};
            press_button();
            #100;
        end
    endtask
    
    // ~~~ TESTING HERE ~~~ //
    initial begin
        clk = 0;
        reset = 1;
        btnR = 0;
        sw = 0;
        
        #100 reset = 0;
        
        // ~~~ TEST XOR ~~~ //
        apply_operand(8'h12);
        apply_operand(8'h34);
        perform_operation(3'b000);
        $display("----- Test XOR -----");
        $display("Result: an = %b, seg = %B, led %b", an, seg, led);
        
        // ~~~ TEST AND ~~~ //
        apply_operand(8'h05);
        apply_operand(8'h03);
        perform_operation(3'b001);
        $display("----- Test AND -----");
        $display("Result: an = %b, seg = %B, led %b", an, seg, led);
        
        // ~~~ TEST OR ~~~ //
        apply_operand(8'hbc);
        apply_operand(8'h44);
        perform_operation(3'b010);
        $display("----- Test OR -----");
        $display("Result: an = %b, seg = %B, led %b", an, seg, led);
        
        // ~~~ TEST ADD ~~~ //
        apply_operand(8'h45);
        apply_operand(8'h32);
        perform_operation(3'b011);
        $display("----- Test ADD -----");
        $display("Result: an = %b, seg = %B, led %b", an, seg, led);
        
        // ~~~ TEST SUB ~~~ //
        apply_operand(8'hFF);
        apply_operand(8'hFF);
        perform_operation(3'b100);
        $display("----- Test SUB -----");
        $display("Result: an = %b, seg = %B, led %b", an, seg, led);
        
        // ~~~ TEST Switch OPERATION ~~~ //
        apply_operand(8'hF0);
        apply_operand(8'h0F);
        perform_operation(3'b100);
        perform_operation(3'b000);
        $display("----- Test Switch OPERATION -----");
        $display("Result: an = %b, seg = %B, led %b", an, seg, led);
        
        // ~~~ TEST RESTART ~~~ //
        apply_operand(8'hF0);
        apply_operand(8'h0F);
        perform_operation(3'b010);
        reset = 1;
        #50;
        reset = 0;
        #100
        apply_operand(8'h88);
        apply_operand(8'h22);
        perform_operation(3'b100);
        $display("----- Test Switch OPERATION -----");
        $display("Result: an = %b, seg = %B, led %b", an, seg, led);
        
        $stop;
    end
endmodule
