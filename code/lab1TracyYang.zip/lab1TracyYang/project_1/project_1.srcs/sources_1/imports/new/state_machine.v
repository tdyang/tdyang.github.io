`timescale 1ns / 1ps

module state_machine(
    input               clk, reset_n, btnR, done,
    output reg [2:0] state
    );
    
    // -- clks & enable -- //
    reg [26:0]          one_sec_counter;
    wire                one_sec_enable;
    
    // -- state machine vars -- //
    parameter           s_idle = 3'b000;
    parameter           s_set_time = 3'b001;
    parameter           s_load_time = 3'b010;
    parameter           s_count_down = 3'b011;
    parameter           s_flashing = 3'b100;
    reg                 curr_state;
    reg                 next_state;

    
    always@(*)
        state = curr_state;
    
    // ~~~ state & clock ~~~ //
    always @(posedge clk or posedge reset_n)
        if (reset_n == 1'b1) begin
            curr_state <= s_idle;
        end else
            curr_state <= next_state;
            
           
    
    // ~~~ state machine ~~~ //
    always @(*) begin
        if(reset_n)
            next_state =  s_idle;
        else begin      
            case (curr_state)
                s_idle : begin
                    if (btnR) begin
                        next_state = s_load_time;
                    end 
                    else
                        next_state = s_idle;
                    end
                s_set_time : begin
                    if (btnR) begin
                        next_state = s_count_down; //btnR confirms set time
                    end
                    else
                        next_state = s_set_time;
                 end
                s_load_time : begin
                    if (btnR) begin
                        next_state = s_count_down;
                    end
                    else begin
                        next_state = s_load_time;
                    end
                end
                s_count_down : begin
                    if (done) begin
                        next_state = s_flashing;
                    end else if (btnR) begin //reset clk to prev set time
                        next_state = s_set_time;
                    end  
                    else begin
                        next_state = s_count_down;
                    end
                end 
                s_flashing : begin
                    next_state = s_load_time;
                    end
                default : next_state = s_idle;
            endcase 
        end
    end     
endmodule
