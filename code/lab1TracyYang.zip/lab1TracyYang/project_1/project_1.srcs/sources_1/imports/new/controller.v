`timescale 1ns / 1ps

module controller(
    input               clk, btnL, btnR,  
    input [7:0]         sw,
    output [3:0]    an,
    output [6:0]    seg,
    output reg [15:0] led
    );
    
    // -- top-level variables -- //
    reg [7:0] segval, original;
    reg doneflag;
    reg [2:0] flash;
    wire done;
    
    // -- submodule instances -- //    
    seven_seg SS(
        .sw(segval),
        .clk(clk),          //inputs
        .reset_n(btnL),        
        .an(an),            //outputs  
        .seg(seg)
    );
    
    // -- state machine vars -- //
    parameter           s_idle = 3'b000;
    parameter           s_set_time = 3'b001;
    parameter           s_load_time = 3'b010;
    parameter           s_count_down = 3'b011;
    parameter           s_flashing = 3'b100;
    reg [2:0]                curr_state;
    reg [2:0]                next_state;

        
    // ~~~ state & clock ~~~ //
    always @(posedge clk or posedge btnL)
        if (btnL == 1'b1) begin
            curr_state <= s_idle;
        end else
            curr_state <= next_state;
    
    assign done = (doneflag == 1'b1) ? 1'b1 : 1'b0;
    
    // ~~~ state machine ~~~ //
    always @(*) begin
        if(btnL)
            next_state =  s_idle;
        else begin      
            case (curr_state)
                s_idle : begin
                    if (btnR) begin
                        next_state = s_load_time;
                    end else
                        next_state = s_idle;
                end
                s_set_time : begin
                    if (btnR) begin
                        next_state = s_count_down; //btnR confirms set time
                    end else
                        next_state = s_set_time;
                end
                s_load_time : begin
                    if (btnR) begin
                        next_state = s_count_down;
                    end else begin
                        next_state = s_load_time;
                    end
                end
                s_count_down : begin
                    if (done) begin //done counting
                        next_state = s_flashing;
                    end else if (btnR) begin //pause
                        next_state = s_set_time;
                    end else begin //continue counting down
                        next_state = s_count_down;
                    end
                end 
                s_flashing : begin
                    if(flash == 3'd5) begin
                        next_state = s_load_time;
                    end
                    else
                        next_state = s_flashing;
                    end
                default : next_state = s_idle;
            endcase 
        end
    end     
    
    // -- clks & enable -- //
    reg [26:0]          one_sec_counter;
    wire                one_sec_enable;
    
    always @(posedge clk or posedge btnL) begin
        if (btnL) begin //initializes or resets
            one_sec_counter <= 0; 
            flash <= 0;   
            led <= 16'd0;    
        end else begin
            if (one_sec_counter >= 99999999) // overflow resets timer back 
                one_sec_counter <= 0;
            else
                one_sec_counter <= one_sec_counter + 1;
                
            if (curr_state == s_flashing && one_sec_enable && done) begin
                if(flash[0]) begin
                    led <= ~led;
                end else
                    flash <= flash + 1;      
            end else if (flash >> 5)
                doneflag <= 0;
        end
    end
     
    assign one_sec_enable = (one_sec_counter == 99999999) ? 1'b1 : 1'b0;  
    
    always @(posedge clk or posedge btnL) begin
        if (btnL) begin
            segval <= 0;
            doneflag <= 0;
            original <= 0;
        end else begin
            
//            if (curr_state != s_count_down) begin
//                doneflag <= 0;
//            end else if (curr_state == s_count_down) doneflag <= 1;
            // changing sw data to match cases
            if (curr_state == s_idle) begin                
                if (btnR) begin //gets sw values moves to the next state
                    segval <= sw;
                    original <= sw;
                end else begin
                    segval <= segval;
                    original <= original;
                end
            end
            else if(curr_state == s_set_time || curr_state == s_load_time) begin
                segval <= segval;
                original <= original;
            end
            else if(curr_state == s_count_down && one_sec_enable) begin
                segval <= segval - 1; // time decrements
                original <= original;
                if(segval == 0)
                    doneflag <= 1;
                else
                    doneflag <= 0;
            end
            else if (curr_state == s_flashing) begin
                segval <= original;
                original <= original;
            end
        end
    end
        
endmodule
