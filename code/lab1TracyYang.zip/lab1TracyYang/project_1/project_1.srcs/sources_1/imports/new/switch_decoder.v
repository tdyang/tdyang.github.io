`timescale 1ns / 1ps

module switch_decoder(
    input [7:0]         sw,
    output reg [15:0]   sw_d
    );
        
    always @(*) begin
        sw_d [11:8] = sw / 60;
        sw_d [7:4] = (sw % 60) / 10;
        sw_d [3:0] = (sw % 60) % 10;
    end
endmodule