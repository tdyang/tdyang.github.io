`timescale 1ns / 1ps

module seven_seg(
    input [7:0] sw,
    input clk, reset_n,
    output reg [3:0] an,
    output reg [6:0] seg
    );
    
    wire [3:0] sec_ones = sw[3:0];
    wire [3:0] sec_tens = sw[7:4];
//    wire [3:0] min = sw_d[11:8];
    
    parameter C_MAX_COUNT = 8000000;
    reg [23:0] led_counter;
    
    function [6:0] dec_sev_seg;
        input [3:0] data;
        case (data)            
            4'h0: dec_sev_seg = 7'b1000000;    // digit 0
            4'h1: dec_sev_seg = 7'b1111001;    // digit 1
            4'h2: dec_sev_seg = 7'b0100100;    // digit 2
            4'h3: dec_sev_seg = 7'b0110000;    // digit 3
            4'h4: dec_sev_seg = 7'b0011001;    // digit 4
            4'h5: dec_sev_seg = 7'b0010010;    // digit 5
            4'h6: dec_sev_seg = 7'b0000010;    // digit 6
            4'h7: dec_sev_seg = 7'b1111000;    // digit 7
            4'h8: dec_sev_seg = 7'b0000000;    // digit 8
            4'h9: dec_sev_seg = 7'b0010000;    // digit 9
            4'ha: dec_sev_seg = 7'b0001000;    // digit A
            4'hb: dec_sev_seg = 7'b0000011;    // digit B
            4'hc: dec_sev_seg = 7'b1000110;    // digit C
            4'hd: dec_sev_seg = 7'b0100001;    // digit D
            4'he: dec_sev_seg = 7'b0000110;    // digit E
            default: dec_sev_seg = 7'b0001110; // digit F
        endcase
    endfunction
    
    always @(posedge clk or posedge reset_n) begin
        if (reset_n == 1'b1)
            led_counter <= 0;
        else begin
            if (led_counter == C_MAX_COUNT)
                led_counter <= 24'd0;
            else
                led_counter <= led_counter + 1;
        end
     end
    
    always @(*) begin
        case(led_counter[19:18])
            2'b00 : begin
                an = 4'b1110;
                seg = dec_sev_seg(sec_ones);
            end 
            2'b01 : begin
                an = 4'b1101;
                seg = dec_sev_seg(sec_tens);
            end
            2'b10 : begin
                an = 4'b1111;
                seg = 7'd0;
            end
            2'b11 : begin
                an = 4'b1111;
                seg = 7'd0;
            end
        endcase
    end
endmodule
