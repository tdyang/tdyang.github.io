# FIXED

main.obj: ../main.c
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/std.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stddef.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/targets/arm/elf/std.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/targets/arm/elf/M4F.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/targets/std.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/System.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/xdc.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types__prologue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/package.defs.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types__epilogue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error__prologue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Main.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/Main_Module_GateProxy.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error__epilogue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Memory.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/Memory_HeapProxy.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert__prologue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Main.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags__prologue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Main.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags__epilogue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert__epilogue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/ISystemSupport.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/System_SupportProxy.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/ISystemSupport.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/System_Module_GateProxy.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/System_SupportProxy.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/System_Module_GateProxy.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/cfg/global.h
main.obj: configPkg/package/cfg/rtos_pem4f.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/Hwi.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/Hwi__prologue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/package/package.defs.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log__prologue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Main.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Text.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log__epilogue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/BIOS.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/BIOS__prologue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/package/package.defs.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/package/BIOS_RtsGateProxy.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/BIOS__epilogue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/IHwi.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/package/package.defs.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/Hwi__epilogue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task__prologue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/package.defs.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/ITaskSupport.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Clock.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/ITimer.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Swi.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/Clock_TimerProxy.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/ITimer.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/Task_SupportProxy.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/ITaskSupport.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task__epilogue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/Task_SupportProxy.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Clock.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Event.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Event__prologue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Clock.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Event__epilogue.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Clock.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/Clock_TimerProxy.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Mailbox.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h
main.obj: C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Event.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/Hwi.h
main.obj: ../kiss_fft.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdlib.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdio.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/math.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_defs.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_limits.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/string.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/xlocale/_string.h
main.obj: ../_kiss_fft_guts.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/limits.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/BIOS.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/package/BIOS_RtsGateProxy.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h
main.obj: C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/interrupt.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/fpu.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/sysctl.h
main.obj: ../Crystalfontz128x128_ST7735.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/grlib/grlib.h
main.obj: ../buttons.h
main.obj: ../adc_sampling.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/inc/hw_memmap.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/gpio.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/pwm.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/pin_map.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/timer.h
main.obj: C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/inc/tm4c1294ncpdt.h
main.obj: ../audio_waveform.h

../main.c:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/std.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stddef.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/targets/arm/elf/std.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/targets/arm/elf/M4F.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/targets/std.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/System.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/xdc.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types__prologue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/package.defs.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types__epilogue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error__prologue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Main.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/Main_Module_GateProxy.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error__epilogue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Memory.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/Memory_HeapProxy.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert__prologue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Main.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags__prologue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Main.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags__epilogue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert__epilogue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/ISystemSupport.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/System_SupportProxy.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/ISystemSupport.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/System_Module_GateProxy.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/System_SupportProxy.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/package/System_Module_GateProxy.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/cfg/global.h:

configPkg/package/cfg/rtos_pem4f.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/Hwi.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/Hwi__prologue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/package/package.defs.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log__prologue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Main.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Text.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log__epilogue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/BIOS.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/BIOS__prologue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/package/package.defs.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/package/BIOS_RtsGateProxy.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IGateProvider.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/BIOS__epilogue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/IHwi.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/package/package.defs.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/Hwi__epilogue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task__prologue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/package.defs.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/ITaskSupport.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Clock.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/ITimer.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Swi.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/Clock_TimerProxy.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/ITimer.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/Task_SupportProxy.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/interfaces/ITaskSupport.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task__epilogue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/Task_SupportProxy.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Clock.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Event.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Event__prologue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Log.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Clock.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Event__epilogue.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Clock.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/package/Clock_TimerProxy.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Mailbox.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IHeap.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/IModule.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Queue.h:

C:/ti/xdctools_3_32_00_06_core/packages/xdc/runtime/Assert.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Event.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Semaphore.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/family/arm/m3/Hwi.h:

../kiss_fft.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdlib.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdio.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/math.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_defs.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_limits.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/string.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/xlocale/_string.h:

../_kiss_fft_guts.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/limits.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/BIOS.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/package/BIOS_RtsGateProxy.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/bios_6_45_02_31/packages/ti/sysbios/knl/Task.h:

C:/ti/ccs1250/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/interrupt.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/fpu.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/sysctl.h:

../Crystalfontz128x128_ST7735.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/grlib/grlib.h:

../buttons.h:

../adc_sampling.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/inc/hw_memmap.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/gpio.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/pwm.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/pin_map.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/driverlib/timer.h:

C:/Users/tracy/ti/tirtos_tivac_2_16_01_14/products/TivaWare_C_Series-2.1.1.71b/inc/tm4c1294ncpdt.h:

../audio_waveform.h:

