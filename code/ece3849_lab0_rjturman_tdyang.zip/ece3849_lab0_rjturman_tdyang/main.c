#include <stdint.h>
#include <stdbool.h>
#include "driverlib/fpu.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "Crystalfontz128x128_ST7735.h"
#include <stdio.h>
#include "buttons.h"

uint32_t gSystemClock; // [Hz] system clock frequency
volatile uint32_t gTime = 8345; // time in hundredths of a second
extern volatile uint32_t gButtons;

int main(void)
{
    IntMasterDisable();

    // Enable the Floating Point Unit, and permit ISRs to use it
    FPUEnable();
    FPULazyStackingEnable();

    // Initialize the system clock to 120 MHz
    gSystemClock = SysCtlClockFreqSet(SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480, 120000000);

    Crystalfontz128x128_Init(); // Initialize the LCD display driver
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP); // set screen orientation

    tContext sContext;
    GrContextInit(&sContext, &g_sCrystalfontz128x128); // Initialize the grlib graphics context
    GrContextFontSet(&sContext, &g_sFontFixed6x8); // select font

    ButtonInit();
    IntMasterEnable();

    // full-screen rectangle
    tRectangle rectFullScreen = {0, 0, GrContextDpyWidthGet(&sContext)-1, GrContextDpyHeightGet(&sContext)-1};
    uint32_t time, mmTime, ssTime, ffTime;
    char str[50];   // string buffer

    while (true) {
        GrContextForegroundSet(&sContext, ClrBlack);
        GrRectFill(&sContext, &rectFullScreen); // fill screen with black

        // Update time display
        time = gTime; // read shared global only once
        mmTime = time / 6000;
        ssTime = (time % 6000) / 100;
        ffTime = ((time % 6000) % 100);

        snprintf(str, sizeof(str), "Time = %02u:%02u:%02u",
                 mmTime, ssTime, ffTime);
        GrContextForegroundSet(&sContext, ClrWhite); // yellow text
        GrStringDraw(&sContext, str, /*length*/ -1, /*x*/ 0, /*y*/ 0, /*opaque*/ false);

        // Update button bits display
        unsigned int btn0 = (gButtons >> 8) & 1;
        unsigned int btn1 = (gButtons >> 7) & 1;
        unsigned int btn2 = (gButtons >> 6) & 1;
        unsigned int btn3 = (gButtons >> 5) & 1;
        unsigned int btn4 = (gButtons >> 4) & 1;
        unsigned int btn5 = (gButtons >> 3) & 1;
        unsigned int btn6 = (gButtons >> 2) & 1;
        unsigned int btn7 = (gButtons >> 1) & 1;
        unsigned int btn8 = (gButtons >> 0) & 1;

        snprintf(str, sizeof(str), "Btn Bits = %u%u%u%u%u%u%u%u%u", btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8);
        GrContextForegroundSet(&sContext, ClrWhite); // yellow text
        GrStringDraw(&sContext, str, /*length*/ -1, /*x*/ 0, /*y*/ 16, /*opaque*/ false);
        GrFlush(&sContext); // flush the frame buffer to the LCD
    }
}
