/*
 * adc_sampling.c
 *
 */
#include <adc_sampling.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "driverlib/adc.h"
#include "sysctl_pll.h"
#include "inc/tm4c1294ncpdt.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "Crystalfontz128x128_ST7735.h"
#include "buttons.h"
#include "driverlib/udma.h"
#pragma DATA_ALIGN(gDMAControlTable, 1024) // address alignment required
tDMAControlTable gDMAControlTable[64]; // uDMA control table (global)

// public global variables
//volatile int32_t gADCBufferIndex = ADC_BUFFER_SIZE - 1; // latest sample index
volatile uint16_t gADCBuffer[ADC_BUFFER_SIZE];          // circular buffer
volatile uint32_t gADCErrors = 0;                       // number of missed ADC deadlines
volatile uint32_t ADCIndex;
volatile uint16_t ADCDraw[128];
volatile float flatlineValue = 0.0f;
extern volatile uint16_t ADCSpectrum[1024];
#define PI 3.14159265358979f
#define NFFT 1024
volatile bool gDMAPrimary = true;

// imported global variables
extern uint32_t gADCSamplingRate;   // [Hz] actual ADC sampling rate
extern uint32_t gSystemClock;       // [Hz] system clock frequency
extern volatile uint32_t gTime;     // time in hundredths of a second
extern volatile uint32_t triggerVoltage;
extern volatile uint16_t mode;
extern volatile uint32_t presses;


void ADCSamplingInit(void) {
    // initialize ADC0 peripheral
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);

    // initialize ADC1 peripheral at GPIO PE0
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_0); // GPIO setup for analog input AIN3
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC1);

    // initialize ADC clock configuration
    uint32_t pll_frequency = SysCtlFrequencyGet(CRYSTAL_FREQUENCY);
    uint32_t pll_divisor = (pll_frequency - 1) / (16 * ADC_SAMPLING_RATE) + 1; // round up
    ADCClockConfigSet(ADC0_BASE, ADC_CLOCK_SRC_PLL | ADC_CLOCK_RATE_FULL, pll_divisor);
    ADCClockConfigSet(ADC1_BASE, ADC_CLOCK_SRC_PLL | ADC_CLOCK_RATE_FULL, pll_divisor);
    gADCSamplingRate = pll_frequency / (16 * pll_divisor);

    // initialize ADC1 sampling sequence 0 w/ priority 0 step 0
    ADCSequenceDisable(ADC1_BASE, 0);
    ADCSequenceConfigure(ADC1_BASE, 0, ADC_TRIGGER_ALWAYS, 0);
    ADCSequenceStepConfigure(ADC1_BASE, 0, 0, ADC_CTL_IE | ADC_CTL_END | ADC_CTL_CH3);  // 0th step, sample channel 3 (AIN3), enable interrupt, +end of sequence
    ADCSequenceEnable(ADC1_BASE, 0);                // enable the sequence. it is now sampling

    // initialize DMA controller
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UDMA);
    uDMAEnable();
    uDMAControlBaseSet(gDMAControlTable);

    // assign DMA channel 24 to ADC1 sequence 0
    uDMAChannelAssign(UDMA_CH24_ADC1_0);
    uDMAChannelAttributeDisable(UDMA_SEC_CHANNEL_ADC10, UDMA_ATTR_ALL);

    // primary DMA channel = first half of the ADC buffer
    uDMAChannelControlSet(UDMA_SEC_CHANNEL_ADC10 | UDMA_PRI_SELECT,
                          UDMA_SIZE_16 | UDMA_SRC_INC_NONE | UDMA_DST_INC_16 |
                          UDMA_ARB_4);
    uDMAChannelTransferSet(UDMA_SEC_CHANNEL_ADC10 | UDMA_PRI_SELECT,
                           UDMA_MODE_PINGPONG, (void*)&ADC1_SSFIFO0_R,
                           (void*)&gADCBuffer[0], ADC_BUFFER_SIZE/2);

    // alternate DMA channel = second half of the ADC buffer
    uDMAChannelControlSet(UDMA_SEC_CHANNEL_ADC10 | UDMA_ALT_SELECT,
                          UDMA_SIZE_16 | UDMA_SRC_INC_NONE | UDMA_DST_INC_16 |
                          UDMA_ARB_4);
    uDMAChannelTransferSet(UDMA_SEC_CHANNEL_ADC10 | UDMA_ALT_SELECT,
                           UDMA_MODE_PINGPONG, (void*)&ADC1_SSFIFO0_R,
                           (void*)&gADCBuffer[ADC_BUFFER_SIZE/2], ADC_BUFFER_SIZE/2);
    uDMAChannelEnable(UDMA_SEC_CHANNEL_ADC10);

    // initialize ADC 1 sequence 0 DMA ping pong
    ADCSequenceDMAEnable(ADC1_BASE, 0); // enable DMA for ADC1 sequence 0
    ADCIntEnableEx(ADC1_BASE, ADC_INT_DMA_SS0); // enable ADC1 sequence 0 DMA interrupt
}

void ADC_ISR(void) {
    ADCIntClearEx(ADC1_BASE, ADC_INT_DMA_SS0); // clear the ADC1 sequence 0 DMA interrupt flag

    // Check the primary DMA channel for end of transfer, and restart if needed.
    if (uDMAChannelModeGet(UDMA_SEC_CHANNEL_ADC10 | UDMA_PRI_SELECT) == UDMA_MODE_STOP) {
        // restart the primary channel (same as setup)
        uDMAChannelTransferSet(UDMA_SEC_CHANNEL_ADC10 | UDMA_PRI_SELECT,
                               UDMA_MODE_PINGPONG, (void*)&ADC1_SSFIFO0_R,
                               (void*)&gADCBuffer[0], ADC_BUFFER_SIZE/2);
        gDMAPrimary = false; // DMA is currently occurring in the alternate buffer
    }

    // Check the alternate DMA channel for end of transfer, and restart if needed.
    // Also set the gDMAPrimary global.
    if (uDMAChannelModeGet(UDMA_SEC_CHANNEL_ADC10 | UDMA_ALT_SELECT) == UDMA_MODE_STOP) {
        // restart the alternate channel (same as setup)
        uDMAChannelTransferSet(UDMA_SEC_CHANNEL_ADC10 | UDMA_ALT_SELECT,
                               UDMA_MODE_PINGPONG, (void*)&ADC1_SSFIFO0_R,
                               (void*)&gADCBuffer[ADC_BUFFER_SIZE/2], ADC_BUFFER_SIZE/2);
        gDMAPrimary = true; // DMA is currently occurring in the primary buffer
    }

    // The DMA channel may be disabled if the CPU is paused by the debugger
    if (!uDMAChannelIsEnabled(UDMA_SEC_CHANNEL_ADC10)) {
        uDMAChannelEnable(UDMA_SEC_CHANNEL_ADC10); // re-enable the DMA channel
    }
}

int32_t getADCBufferIndex(void){
    int32_t index;
    if (gDMAPrimary) { // DMA is currently in the primary channel
        index = ADC_BUFFER_SIZE/2 - 1 -
        uDMAChannelSizeGet(UDMA_SEC_CHANNEL_ADC10 |
        UDMA_PRI_SELECT);
    } else { // DMA is currently in the alternate channel
        index = ADC_BUFFER_SIZE - 1 -
        uDMAChannelSizeGet(UDMA_SEC_CHANNEL_ADC10 |
        UDMA_ALT_SELECT);
    }
    return index;
}

int Snapshot(int triggerDirection, uint16_t triggerVoltage) {
    uint16_t prevVoltage = 0;
    ADCIndex = ADC_BUFFER_WRAP(getADCBufferIndex() - 64);
    prevVoltage = gADCBuffer[ADCIndex];

    bool edgeDetected = false;
    int searchCount = 0;

    while (searchCount < MAX_EDGE_SEARCH) {
        float currentVoltage = gADCBuffer[ADCIndex];
        if (triggerDirection == 0) {  // rising edge
            if (prevVoltage < triggerVoltage && currentVoltage >= triggerVoltage) {
                edgeDetected = true;
                break;
            }
        } else if (triggerDirection == 1) {  // falling edge
            if (prevVoltage > triggerVoltage && currentVoltage <= triggerVoltage) {
                edgeDetected = true;
                break;
            }
        }
        prevVoltage = currentVoltage;
        ADCIndex = ADC_BUFFER_WRAP(ADCIndex - 1);
        searchCount++;
    }

    int cnt;

    // Always collect 128 samples for oscilloscope
    if (!edgeDetected) {
        for (cnt = 0; cnt < 128; cnt++) {
            ADCDraw[cnt] = gADCBuffer[ADCIndex];
            ADCIndex = ADC_BUFFER_WRAP(ADCIndex + 1);
        }
    } else {
        ADCIndex = ADC_BUFFER_WRAP(ADCIndex - 63);
        for (cnt = 0; cnt < 128; cnt++) {
            ADCDraw[cnt] = gADCBuffer[ADCIndex];
            ADCIndex = ADC_BUFFER_WRAP(ADCIndex + 1);
        }
    }

    // If in spectrum mode, also fill the 1024-sample buffer
    if (mode == 0) {
        ADCIndex = ADC_BUFFER_WRAP(getADCBufferIndex() - NFFT);  // Go back NFFT samples
        for (cnt = 0; cnt < NFFT; cnt++) {
            ADCSpectrum[cnt] = gADCBuffer[ADCIndex];
            ADCIndex = ADC_BUFFER_WRAP(ADCIndex + 1);
        }
    }

    return 0;
}


float changeScale(int state) {
    switch (state) {
        case 0: return .1; // 100mV
        case 1: return .2; // 200 mV
        case 2: return .5; // 500 mV
        case 3: return 1;  // 1V
        case 4: return 2;  // 2V
        default: return 1;
    }

}
