/*
 * FIFO.c
 *
 *  Created on: Apr 7, 2025
 *      Author: rjturman
 */


#include <stdint.h>
#include <stdbool.h>
#include "driverlib/fpu.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "Crystalfontz128x128_ST7735.h"
#include <stdio.h>
#include "buttons.h"
#include "adc_sampling.h"
#include <math.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"

#define FIFO_SIZE 11
typedef int DataType;
volatile uint32_t fifo[FIFO_SIZE];
volatile int fifo_head = 0;
volatile int fifo_tail = 0;
volatile int new_tail = 0;
volatile int dataToSend;
volatile uint32_t data;

int fifo_put(uint32_t data)
{
    int new_tail = fifo_tail + 1;
    if (new_tail >= FIFO_SIZE)
    {
        new_tail = 0; // Wrap around
    }
    if (fifo_head != new_tail)
    {    // If the FIFO is not full
        fifo[fifo_tail] = data;    // Store data into the FIFO
        fifo_tail = new_tail;    // Advance FIFO tail index
        return 1;    // Success
    }
    return 0;   // Full
}

int fifo_get(uint32_t *data)
{
    if (fifo_head != fifo_tail)  // If the FIFO is not empty
    {
        *data = fifo[fifo_head];    // Read data from the FIFO
        IntMasterDisable();
        fifo_head++;    // Advance FIFO head index
        if (fifo_head >= FIFO_SIZE)
            fifo_head = 0;    // Wrap around
        IntMasterEnable();
        return 1;    // Success
    }
    return 0;   // empty
}
