#ifndef FIFO_H_
#define FIFO_H_

int fifo_put(uint32_t data);
int fifo_get(uint32_t *data);

#endif /* FIFO_H_ */
