#include <stdint.h>
#include <stdbool.h>
#include "driverlib/fpu.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "Crystalfontz128x128_ST7735.h"
#include <stdio.h>
#include "buttons.h"
#include "adc_sampling.h"
#include <math.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "FIFO.h"
#include "driverlib/timer.h"

#define PWM_FREQUENCY 20000

uint32_t gSystemClock; // [Hz] system clock frequency
volatile uint32_t gTime = 8345; // time in hundredths of a second
volatile uint32_t triggerVoltage = 2048;
volatile uint16_t triggerDirection = 0;
volatile uint16_t scaleState = 0;
volatile bool gSnapshot = false;
volatile bool gLive = true;
volatile uint32_t CountUnloaded;

// outside variables
extern volatile uint16_t ADCDraw[128];
extern volatile uint32_t fifo_head;

int Snapshot(int triggerDirection, uint16_t triggerVoltage);
void drawGrid(tContext sContext);

void SignalInit(void) {
    // M0PWM2, at GPIO PF2= BoosterPack 1 header C1 pin 2
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_2);
    GPIOPinConfigure(GPIO_PF2_M0PWM2);
    GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_2, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD);

    // PWM0 peripheral, gen 1, outputs 2 & 3
    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);

    // system clock w/o division
    PWMClockSet(PWM0_BASE, PWM_SYSCLK_DIV_1);
    PWMGenConfigure(PWM0_BASE, PWM_GEN_1, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);
    PWMGenPeriodSet(PWM0_BASE, PWM_GEN_1, roundf((float)gSystemClock/PWM_FREQUENCY));
    PWMPulseWidthSet(PWM0_BASE, PWM_OUT_2, roundf((float)gSystemClock/PWM_FREQUENCY*0.4f));
    PWMOutputState(PWM0_BASE, PWM_OUT_2_BIT, true);
    PWMGenEnable(PWM0_BASE, PWM_GEN_1);
}

uint32_t CPULoadCount(void) {
    uint32_t CPUUtil = 0;
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER3_BASE, TIMER_A);
    while (!(TimerIntStatus(TIMER3_BASE, false) & TIMER_TIMA_TIMEOUT))
        CPUUtil++;
    return CPUUtil;
}

int main(void) {
    IntMasterDisable();
    // Enable the Floating Point Unit, and permit ISRs to use it
    FPUEnable();
    FPULazyStackingEnable();
    // Initialize the system clock to 120 MHz
    gSystemClock = SysCtlClockFreqSet(SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480, 120000000);
    Crystalfontz128x128_Init(); // Initialize the LCD display driver
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP); // set screen orientation
    tContext sContext;
    GrContextInit(&sContext, &g_sCrystalfontz128x128); // Initialize the grlib graphics context
    GrContextFontSet(&sContext, &g_sFontFixed6x8); // select font
    SignalInit();
    ADCSamplingInit();
    ButtonInit();

    // initialize timer 3 in one-shot mode for polled timing
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);
    TimerDisable(TIMER3_BASE, TIMER_BOTH);
    TimerConfigure(TIMER3_BASE, TIMER_CFG_ONE_SHOT);
    TimerLoadSet(TIMER3_BASE, TIMER_A, gSystemClock / 100); // change number to change refresh time
    CountUnloaded = CPULoadCount();

    IntMasterEnable();
    // full-screen rectangle
    tRectangle rectFullScreen = {0, 0, GrContextDpyWidthGet(&sContext)-1, GrContextDpyHeightGet(&sContext)-1};

    char strScale[50];
    char strLoad[50];
    char strTrigger[50];
    while (true) {
        GrContextForegroundSet(&sContext, ClrBlack);
        GrRectFill(&sContext, &rectFullScreen); // fill screen with black

        // screen math
        int screenWidth = GrContextDpyWidthGet(&sContext);
        int screenHeight = GrContextDpyHeightGet(&sContext);
        int x;
        int y;

        GrContextForegroundSet(&sContext, ClrBlue); // set grid color

        for (x = screenWidth / 2; x < screenWidth; x += PIXELS_PER_DIV)
            GrLineDraw(&sContext, x, 0, x, screenHeight);

        for (x = screenWidth / 2; x > 0; x -= PIXELS_PER_DIV)
            GrLineDraw(&sContext, x, 0, x, screenHeight);

        for (y = screenHeight / 2; y < screenHeight; y += PIXELS_PER_DIV)
            GrLineDraw(&sContext, 0, y, screenWidth, y);

        for (y = screenHeight / 2; y > 0; y -= PIXELS_PER_DIV)
            GrLineDraw(&sContext, 0, y, screenWidth, y);

        GrContextForegroundSet(&sContext, ClrYellow); // set sample color

        uint16_t scaleStateLocal = scaleState;
        uint16_t triggerDirectionLocal = triggerDirection;
        static bool snapshotCaptured = false;

        if (gLive) {
            Snapshot(triggerDirectionLocal, triggerVoltage);
            snapshotCaptured = false;
        } else if (gSnapshot || !snapshotCaptured){
            Snapshot(triggerDirectionLocal, triggerVoltage);
            snapshotCaptured = true;
            gSnapshot = false;
        }

        GrContextForegroundSet(&sContext, ClrWhite);
        // scale print
        float fScale = changeScale(scaleStateLocal);
        GrStringDraw(&sContext, strScale, /*length*/ -1, /*x*/ 0, /*y*/ 0, /*opaque*/ false);
        snprintf(strScale, sizeof(strScale), "Scale: %.1f", fScale);

        //cpu load print
        int CountLoaded = CPULoadCount();
        float CPULoad = 1.0f - (float) CountLoaded / CountUnloaded;
        GrStringDraw(&sContext, strLoad, -1, 0, 10, false);
        snprintf(strLoad, sizeof(strLoad), "CPU Load: %.02f", (CPULoad * 100));

        // trigger direction print
        const char *cTrigger;
        if (triggerDirection)
            cTrigger = "rising";
        else
            cTrigger = "falling";
        GrStringDraw(&sContext, strTrigger, -1, 0, 20, false);
        snprintf(strTrigger, sizeof(strTrigger), "Trigger: %s", cTrigger);

        GrContextForegroundSet(&sContext, ClrYellow);
        int i;
        for (i = 0; i < 127; i++) {
            int sample = ADCDraw[i];
            int nextSample = ADCDraw[i + 1];
            int centerY = LCD_VERTICAL_MAX / 2;
            float amplitude = (LCD_VERTICAL_MAX / 4) / fScale;
            if (amplitude > (LCD_VERTICAL_MAX/2) - 1)
                amplitude = (LCD_VERTICAL_MAX/2) - 1;
            int currentY = roundf(centerY - ((sample - 2048) * amplitude) / 2048);
            int nextY = roundf(centerY - ((nextSample - 2048) * amplitude) / 2048);

            GrLineDraw(&sContext, i, currentY, i + 1, nextY);
        }

        uint32_t local_fifo = 0;
        fifo_get(&local_fifo);
        if (local_fifo == 1){
            //running = !running;
        }
        if (local_fifo == 2){
            gLive = !gLive;
            if (!gLive)
                gSnapshot = true;
        }
        if (local_fifo == 4){
            triggerDirection = !triggerDirection;
            if (!gLive)
                gSnapshot = true;
            else
                gSnapshot = false;
        }
        if (local_fifo == 8) {
            scaleState = (scaleState + 1) % 5;
            gSnapshot = true;
            if (!gLive)
                gSnapshot = true;
        }

        GrFlush(&sContext); // flush the frame buffer to the LCD
    }
}
