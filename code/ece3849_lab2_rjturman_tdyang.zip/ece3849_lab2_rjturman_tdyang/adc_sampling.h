/*
 * adc_sampling.h
 *
 */

#ifndef ADC_SAMPLING_H_
#define ADC_SAMPLING_H_

#include <stdint.h>

// variables
#define ADC_SAMPLING_RATE 1000000   // [samples/sec] desired ADC sampling rate
#define CRYSTAL_FREQUENCY 25000000  // [Hz] crystal oscillator frequency used to calculate clock rates
#define ADC_BUFFER_SIZE 2048 // size must be a power of 2
#define ADC_BUFFER_WRAP(i) ((i) & (ADC_BUFFER_SIZE - 1)) // index wrapping macro
#define ADC_INT_PRIORITY 30
#define VIN_RANGE 3.3
#define PIXELS_PER_DIV 20
#define ADC_BITS 12
#define MAX_EDGE_SEARCH 1024  // Max samples to look back for edge

// outside variables
extern volatile int32_t gADCBufferIndex;
extern volatile uint16_t gADCBuffer[ADC_BUFFER_SIZE];
extern volatile uint32_t gADCErrors;
extern volatile uint16_t triggerDirection;
extern volatile uint32_t triggerVoltage;

// functions
void ADCSamplingInit(void);
void ADC_ISR(void);
int Snapshot(int triggerDirection, uint16_t triggerVoltage);
float changeScale(int state);

#endif /* ADC_SAMPLING_H_ */
